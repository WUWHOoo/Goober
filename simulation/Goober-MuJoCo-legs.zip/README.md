# Goober leg model

Open goober.xml with its meshes directory beside it. In the existing Colab notebook, upload this ZIP in the Goober inspection cell. The model has eight leg actuators and nine joints including the floating base. Its neutral pose matches the saved Fusion reference after conversion to metres and a Z-up, X-forward walking frame.

## Control order

The eight entries in data.ctrl are joint angle targets in radians. The order is left hip yaw, left hip pitch, left knee pitch, left ankle pitch, then the same four joints on the right. Zero targets correspond to the CAD pose. Left and right are defined looking along +X with +Z up. Both hip-yaw axes point up. Both legs use the same sagittal rotation convention.

To advance one simulated second from the initial pose after loading goober in the notebook:

```python
data = mujoco.MjData(goober)
data.ctrl[:] = 0.0
for _ in range(round(1 / goober.opt.timestep)):
    mujoco.mj_step(goober, data)
print(data.time, data.qpos[:3])
```

## Simulation assumptions

Joint centres and axes come from the servo output splines and gearbox carriers. The ankle horn follows the shin and its servo case follows the foot. The neck, head and beak are rigid with the torso. The gearboxes use output-level joints. The current moving model totals 2.008 kg. The torso link is 1.186 kg, including attached head, neck, servos and a 600 g combined battery/PCB payload. The payload is approximated as a point mass at the printed torso shell and lid's combined CAD centre of mass. Its precise mounting position and dimensions are unknown.

Measured masses used per leg are 90 g for printed actuator parts, 20 g for the printed thigh, 18 g for the printed tibia, 14 g for the printed ankle/foot, 60 g for each of three large servos, and 93 g for the 5010 motor. The printed torso shell and lid together are taken as approximately 150 g. Provisional printed masses are 10 g for the lower neck, 13 g for the upper neck, 57 g for the head shell, and 7 g for the lower bill. External servo horns, mounting hardware, bearings and small servos still use CAD estimates. The printed measurements and motors sum to 980 g before the 600 g payload. Component centres and inertia tensors were reweighted from the CAD geometry and combined for each moving link.

Initial symmetric joint travel is 15 degrees for hip yaw, 35 degrees for hip pitch and knee pitch, and 25 degrees for ankle pitch. Position gains, force limits, joint damping, armature and ground friction are simulation estimates. Floor contacts use convex hulls of the feet, leg segments, body shell and head. Robot self-collision is disabled. Verify physical stops, servo speed and output torque before comparing policy behaviour with hardware.
